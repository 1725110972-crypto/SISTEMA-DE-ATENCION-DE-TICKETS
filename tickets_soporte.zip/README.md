# Sistema de Atencion de Tickets (Ejercicio 3)

Empresa de soporte tecnico con DOS filas FIFO: una normal y una
prioritaria. La prioritaria siempre se atiende antes que la normal,
pero DENTRO de cada una se respeta estrictamente el orden de llegada.

Misma estructura que los ejercicios anteriores (web.py + controllers +
views + tda), reutilizando el mismo TDA `Cola` del ejercicio de la
ventanilla escolar — aqui se usan DOS instancias en vez de una.

## Estructura

```
tickets_soporte/
├── app.py
├── controllers/
│   ├── estado.py                 # las 2 colas + contadores + regla de prioridad
│   ├── index.py
│   ├── tickets.py                 # muestra ambas filas, siguiente y estadisticas
│   ├── registrar_ticket.py        # formulario + encolar en la fila correcta
│   └── atender_ticket.py          # atiende de la fila que corresponda
├── tda/
│   └── cola.py                    # el TDA: Cola (FIFO) -- igual que el ejercicio anterior
├── temporal/
│   └── app.py
└── views/
    ├── layout.html
    ├── index.html
    ├── tickets.html
    ├── registrar_ticket.html
    └── atender_ticket.html
```

## Requerimientos pedidos -> donde estan implementados

| Requerimiento | Donde |
|---|---|
| 1. Registrar ticket | `controllers/registrar_ticket.py` -> encola en `cola_prioritaria` o `cola_normal` segun el campo "Prioridad" |
| 2. Atender el siguiente ticket | `controllers/atender_ticket.py` -> `cola_a_atender()` + `Cola.desencolar()` |
| 3. Consultar siguiente ticket | Se muestra en `/tickets` -> `cola_a_atender()` + `Cola.frente()` (no quita a nadie) |
| 4. Mostrar las filas | `/tickets` -> una tabla para la fila prioritaria y otra para la normal, cada una en su propio orden FIFO |
| 5. Estadisticas (minimo 3) | `/tickets` muestra 4: total en espera, total por fila (normal/prioritaria), tiempo total estimado de espera, y tickets atendidos en la sesion |

## La regla de "quien se atiende primero"

Vive en `controllers/estado.py`, en una sola funcion:

```python
def cola_a_atender():
    if not cola_prioritaria.esta_vacia():
        return cola_prioritaria
    return cola_normal
```

Si hay CUALQUIER ticket en la fila prioritaria, se atiende de ahi
(respetando quien llego primero a esa fila). Solo si la prioritaria
esta vacia, se pasa a atender de la normal. Esto cumple exactamente lo
que pide el ejercicio: "si existen 3 solicitudes prioritarias, debera
atenderse primero la que llego primero" -- el orden FIFO nunca se
rompe DENTRO de cada fila, solo hay preferencia de una fila sobre otra.

## Datos de cada ticket

- Numero de ticket (se asigna solo, automatico y consecutivo)
- Nombre del cliente
- Tipo de problema
- Prioridad (Normal o Prioritaria)
- Tiempo estimado (minutos)

## Por que no hay base de datos

Igual que en el ejercicio de la ventanilla escolar: un ticket en espera
es informacion transitoria (se atiende y ya no se vuelve a consultar
como tal). Las dos colas viven en memoria mientras el servidor esta
corriendo (`controllers/estado.py`). Si se pidiera un reporte historico
de tickets atendidos en el dia, ahi si convendria agregar una base de
datos para ese historial.

## Como correrlo

```bash
pip install -r requirements.txt
python3 app.py
```

Entra a `/tickets` para ver ambas filas. Desde ahi puedes registrar
tickets y atender al que le toque (prioritaria primero).
