import web

urls = (
    '/', 'controllers.index.Index',
    '/tickets', 'controllers.tickets.Tickets',
    '/registrar_ticket', 'controllers.registrar_ticket.RegistrarTicket',
    '/atender_ticket', 'controllers.atender_ticket.AtenderTicket',
)
app = web.application(urls, globals())

if __name__ == "__main__":
    app.run()
