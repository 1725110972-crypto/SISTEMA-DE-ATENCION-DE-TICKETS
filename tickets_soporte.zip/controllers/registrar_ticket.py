import web

from controllers.estado import cola_normal, cola_prioritaria, generar_numero_ticket

render = web.template.render('views', base='layout')


class RegistrarTicket:
    def GET(self):
        return render.registrar_ticket(None)

    def POST(self):
        entrada = web.input(
            nombre_cliente='', tipo_problema='', prioridad='Normal', tiempo_estimado=''
        )

        nombre_cliente = entrada.nombre_cliente.strip()
        tipo_problema = entrada.tipo_problema.strip()
        prioridad = entrada.prioridad.strip()
        tiempo_estimado_texto = entrada.tiempo_estimado.strip()

        if not nombre_cliente or not tipo_problema or not tiempo_estimado_texto:
            return render.registrar_ticket(
                "Nombre del cliente, tipo de problema y tiempo estimado son obligatorios."
            )

        try:
            tiempo_estimado = int(tiempo_estimado_texto)
        except ValueError:
            return render.registrar_ticket(
                "El tiempo estimado debe ser un numero entero de minutos."
            )

        if prioridad not in ('Normal', 'Prioritaria'):
            prioridad = 'Normal'

        ticket = {
            'numero_ticket': generar_numero_ticket(),
            'nombre_cliente': nombre_cliente,
            'tipo_problema': tipo_problema,
            'prioridad': prioridad,
            'tiempo_estimado': tiempo_estimado,
        }

        if prioridad == 'Prioritaria':
            cola_prioritaria.encolar(ticket)
        else:
            cola_normal.encolar(ticket)

        # Redirect RELATIVO a mano (no web.seeother): dentro de Codespaces,
        # seeother arma la URL con el host interno del contenedor y te saca
        # de la URL publica (...app.github.dev).
        web.ctx.status = '303 See Other'
        web.header('Location', '/tickets')
        return ''
