import web

from controllers.estado import cola_a_atender, registrar_atencion

render = web.template.render('views', base='layout')


class AtenderTicket:
    def GET(self):
        cola = cola_a_atender()
        atendido = cola.desencolar()

        if atendido:
            registrar_atencion()

        return render.atender_ticket(atendido)
