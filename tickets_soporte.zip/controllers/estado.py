# -*- coding: utf-8 -*-
"""
Estado compartido del sistema de tickets, mientras el servidor este
corriendo:
- cola_normal y cola_prioritaria: una instancia de Cola para cada fila.
- un contador para asignar numero de ticket automaticamente.
- un contador de cuantos tickets se han atendido en total (para las
  estadisticas).
"""
from tda.cola import Cola

cola_normal = Cola()
cola_prioritaria = Cola()

# Listas de un solo elemento usadas como "contador mutable" compartido,
# para no tener que usar 'global' dentro de las funciones de abajo.
_siguiente_numero = [1]
_tickets_atendidos = [0]


def generar_numero_ticket():
    """Asigna un folio unico y consecutivo a cada ticket nuevo."""
    numero = _siguiente_numero[0]
    _siguiente_numero[0] += 1
    return numero


def registrar_atencion():
    """Suma uno al contador de tickets atendidos (para estadisticas)."""
    _tickets_atendidos[0] += 1


def total_atendidos():
    return _tickets_atendidos[0]


def cola_a_atender():
    """
    Regresa la cola de la que debe salir el SIGUIENTE ticket en general:
    la fila prioritaria tiene preferencia absoluta sobre la normal. Si
    la prioritaria tiene algo esperando, se atiende de ahi; si esta
    vacia, se atiende de la normal. Dentro de cada una, el orden sigue
    siendo FIFO (quien llego primero a esa fila, sale primero de ella).
    """
    if not cola_prioritaria.esta_vacia():
        return cola_prioritaria
    return cola_normal
