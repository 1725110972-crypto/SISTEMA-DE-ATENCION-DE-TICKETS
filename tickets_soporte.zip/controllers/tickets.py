import web

from controllers.estado import (
    cola_normal, cola_prioritaria, cola_a_atender, total_atendidos,
)

render = web.template.render('views', base='layout')


class Tickets:
    def GET(self):
        normales = cola_normal.obtener_todos()
        prioritarios = cola_prioritaria.obtener_todos()

        cola_siguiente = cola_a_atender()
        siguiente = cola_siguiente.frente()
        if siguiente is None:
            nombre_fila_siguiente = None
        elif cola_siguiente is cola_prioritaria:
            nombre_fila_siguiente = 'Prioritaria'
        else:
            nombre_fila_siguiente = 'Normal'

        total_normal = cola_normal.tamano()
        total_prioritaria = cola_prioritaria.tamano()
        total_en_espera = total_normal + total_prioritaria

        tiempo_total = sum(t['tiempo_estimado'] for t in normales + prioritarios)

        return render.tickets(
            normales, prioritarios,
            siguiente, nombre_fila_siguiente,
            total_normal, total_prioritaria, total_en_espera,
            tiempo_total, total_atendidos(),
        )
