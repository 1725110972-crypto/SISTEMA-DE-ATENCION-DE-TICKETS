# -*- coding: utf-8 -*-
"""
TDA: Cola (FIFO - Primeras Entradas, Primeras Salidas)
--------------------------------------------------------
Se usa UNA instancia de esta clase por cada fila (una para tickets
normales, otra para tickets prioritarios). La cola en si no sabe nada
de prioridades: solo garantiza que, DENTRO de ella, el primero en
entrar es el primero en salir. La regla de "la prioritaria se atiende
antes que la normal" vive en controllers/estado.py, no aqui.
"""


class Cola:
    def __init__(self):
        self._datos = []

    def __len__(self):
        return len(self._datos)

    def encolar(self, elemento):
        """Agrega un elemento al FINAL de la fila."""
        self._datos.append(elemento)

    def desencolar(self):
        """
        Quita y regresa el elemento del FRENTE de la fila. Si la fila
        esta vacia, regresa None en vez de lanzar un error.
        """
        if self.esta_vacia():
            return None
        return self._datos.pop(0)

    def frente(self):
        """Consulta quien es el siguiente, SIN quitarlo de la fila."""
        if self.esta_vacia():
            return None
        return self._datos[0]

    def esta_vacia(self):
        return len(self._datos) == 0

    def tamano(self):
        return len(self._datos)

    def obtener_todos(self):
        """Regresa la fila completa, en orden de llegada."""
        return list(self._datos)
